import React, { useState } from 'react';
import api from '../services/api';

const NovaVenda = () => {
  const [products, setProducts] = useState([]);
  const [productInput, setProductInput] = useState('');
  const [quantityInput, setQuantityInput] = useState(1);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleAddProduct = () => {
    if (!productInput || quantityInput <= 0) {
      setError('Informe um produto e quantidade válida.');
      return;
    }

    setProducts([...products, { name: productInput, quantity: quantityInput }]);
    setProductInput('');
    setQuantityInput(1);
    setError('');
  };

  const handleSubmitSale = async () => {
    if (products.length === 0) {
      setError('Adicione pelo menos um produto para realizar a venda.');
      return;
    }

    try {
      const response = await api.post('/nova-venda', { products });
      setSuccess('Venda realizada com sucesso!');
      setProducts([]); 
      setError('');
    } catch (err) {
      setError('Erro ao realizar a venda. Tente novamente.');
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
      <h2>Nova Venda</h2>

      {error && <p style={{ color: 'red' }}>{error}</p>}
      {success && <p style={{ color: 'green' }}>{success}</p>}

      <div style={{ marginBottom: '20px' }}>
        <input
          type="text"
          placeholder="Nome do produto"
          value={productInput}
          onChange={(e) => setProductInput(e.target.value)}
          style={{ padding: '8px', width: '70%', marginRight: '10px' }}
        />
        <input
          type="number"
          min="1"
          placeholder="Quantidade"
          value={quantityInput}
          onChange={(e) => setQuantityInput(Number(e.target.value))}
          style={{ padding: '8px', width: '20%' }}
        />
        <button onClick={handleAddProduct} style={{ padding: '10px 20px', marginLeft: '10px' }}>
          Adicionar
        </button>
      </div>

      <ul>
        {products.map((product, index) => (
          <li key={index}>
            {product.name} - {product.quantity}
          </li>
        ))}
      </ul>

      <button onClick={handleSubmitSale} style={{ padding: '10px 20px', marginTop: '20px' }}>
        Finalizar Venda
      </button>
    </div>
  );
};

export default NovaVenda;
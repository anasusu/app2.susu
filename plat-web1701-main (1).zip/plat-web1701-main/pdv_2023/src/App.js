import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './Login';
import NovaVenda from './NovaVenda';
import AddClient from './AddClient';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/nova-venda" element={<NovaVenda />} />
        <Route path="/adicionar-cliente" element={<AddClient />} />
      </Routes>
    </Router>
  );
}

export default App;